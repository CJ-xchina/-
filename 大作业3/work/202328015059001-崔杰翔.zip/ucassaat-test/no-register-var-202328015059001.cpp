int main(void) {
    // 违背规则
    register int a = 1;
    register int b = 3;
    return a;
}