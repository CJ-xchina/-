double cin = 2;
double endl = 4;
int main(void) {
    unsigned int cin = 0;
    unsigned int cout = 1;
    unsigned int endl = 2;
    return 0;
}