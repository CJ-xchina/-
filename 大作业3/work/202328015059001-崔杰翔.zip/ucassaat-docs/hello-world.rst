.. title:: clang-tidy - ucassaat-hello-world

ucassaat-hello-world
====================

FIXME: Describe what patterns does the check detect and why. Give examples.
